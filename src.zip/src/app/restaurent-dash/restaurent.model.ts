export class RestaurentData{
   
    id:any='';
    name:String='';
    email: string='';
    mobile: string='';
    address: string='';
    service: string='';
}